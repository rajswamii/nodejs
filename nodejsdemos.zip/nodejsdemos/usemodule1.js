var m1=require("./module1");
var f=m1.factorial(5);
console.log("factorial : "+f);